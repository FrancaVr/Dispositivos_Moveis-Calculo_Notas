package com.example.calculonotas;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText inputNome, inputEmail, inputIdade, inputDisciplina, inputNota1, inputNota2;
    TextView textoResumo;
    Button btEnviar, btLimpar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputNome = findViewById(R.id.inputNome);
        inputEmail = findViewById(R.id.inputEmail);
        inputIdade = findViewById(R.id.inputIdade);
        inputDisciplina = findViewById(R.id.inputDisciplina);
        inputNota1 = findViewById(R.id.inputNota1);
        inputNota2 = findViewById(R.id.inputNota2);
        textoResumo = findViewById(R.id.textoResumo);
        btEnviar = findViewById(R.id.btEnviar);
        btLimpar = findViewById(R.id.btLimpar);

        btEnviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View usarBotao) {
                validacao();
            }
        });

        btLimpar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                limpar();
            }
        });
    }

    private void validacao() {
        textoResumo.setText(""); // Limpa o resumo anterior

        String nomeResumo, emailResumo, idadeResumo, disciplinaResumo, nota1Resumo, nota2Resumo, mediaResumo, aprovadoResumo;

        boolean notasValidas = true;

        String nome = inputNome.getText().toString();
        if (nome.isEmpty()) {
            nomeResumo = "Nenhum nome foi informado!";
        } else {
            nomeResumo = nome;
        }

        String email = inputEmail.getText().toString();
        if (email.isEmpty()) {
            emailResumo = "Nenhum email foi informado!";
        } else {
            int posicao = email.indexOf("@");
            if (posicao < 3 || !email.contains("@")) {
                emailResumo = "O email informado é inválido!";
            } else {
                emailResumo = email;
            }
        }

        String idadeStr = inputIdade.getText().toString();
        int idade = 0;
        if (idadeStr.isEmpty()) {
            idadeResumo = "Nenhuma idade foi informada!";
        } else {
            try {
                idade = Integer.parseInt(idadeStr);
                if (idade < 0) {
                    idadeResumo = "A idade informada deve ser um número positivo!";
                } else {
                    idadeResumo = String.valueOf(idade);
                }
            } catch (NumberFormatException e) {
                idadeResumo = "A idade deve ser um número válido!";
            }
        }

        String disciplina = inputDisciplina.getText().toString();
        if (TextUtils.isEmpty(disciplina)) {
            disciplinaResumo = "Não foi informada nenhuma disciplina!";
        } else {
            disciplinaResumo = disciplina;
        }

        double nota1 = 0.0;
        double nota2 = 0.0;

        String nota1Str = inputNota1.getText().toString();
        String nota2Str = inputNota2.getText().toString();

        if (nota1Str.isEmpty()) {
            nota1Resumo = "Nota não informada!";
            notasValidas = false;
        } else {
            try {
                nota1 = Double.parseDouble(nota1Str);
                if (nota1 < 0.0 || nota1 > 10.0) {
                    nota1Resumo = "A nota 1 deve estar entre 0 e 10!";
                    notasValidas = false;
                } else {
                    nota1Resumo = String.valueOf(nota1);
                }
            } catch (NumberFormatException e) {
                nota1Resumo = "A nota 1 deve ser um número válido!";
                notasValidas = false;
            }
        }

        if (nota2Str.isEmpty()) {
            nota2Resumo = "Nota não informada!";
            notasValidas = false;
        } else {
            try {
                nota2 = Double.parseDouble(nota2Str);
                if (nota2 < 0.0 || nota2 > 10.0) {
                    nota2Resumo = "A nota 2 deve estar entre 0 e 10!";
                    notasValidas = false;
                } else {
                    nota2Resumo = String.valueOf(nota2);
                }
            } catch (NumberFormatException e) {
                nota2Resumo = "A nota 2 deve ser um número válido!";
                notasValidas = false;
            }
        }

        if (notasValidas) {
            double media = (nota1 + nota2) / 2.0;
            mediaResumo = String.format("%.2f", media);

            if (media >= 6.0) {
                aprovadoResumo = "Aprovado";
            } else {
                aprovadoResumo = "Reprvado";
            }
        } else {
            mediaResumo = "As notas devem ser válidas para fazer o cálculo.";
            aprovadoResumo = ".";
        }

        String quadroResumo = "Nome do aluno: " + nomeResumo + "\n" +
                "Email do aluno: " + emailResumo + "\n" +
                "Idade do aluno: " + idadeResumo + "\n" +
                "Disciplina: " + disciplinaResumo + "\n" +
                "Nota 1ª Bimestre: " + nota1Resumo + "\n" +
                "Nota 2ª Bimestre: " + nota2Resumo + "\n" +
                "Média Final: " + mediaResumo + "\n" +
                "Situação do aluno: " + aprovadoResumo + "\n";

        textoResumo.setText(quadroResumo);
    }

    private void limpar() {
        inputNome.setText("");
        inputEmail.setText("");
        inputIdade.setText("");
        inputDisciplina.setText("");
        inputNota1.setText("");
        inputNota2.setText("");
        textoResumo.setText("");
    }
}

